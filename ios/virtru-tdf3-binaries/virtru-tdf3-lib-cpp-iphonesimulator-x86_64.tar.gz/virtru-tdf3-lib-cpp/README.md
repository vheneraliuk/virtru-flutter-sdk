# Virtru TDF3 SDK

## License

The following files are covered under the MIT license:

### Cpp Interface and sample

* tdf_constants.h
* tdf_exception.h
* tdf_logging_interface.h
* virtru_client.h
* virtru_encrypt_file_params.h
* virtru_encrypt_steam_params.h
* virtru_encrypt_data_params.h
* virtru_encrypt_string_params.h
* virtru_encrypt_params.h
* virtru_policy.h
* virtru_sample.cpp
* CMakeLists.txt

### C Interface and sample

* virtru_client_c.h
* virtru_constants_c.h
* virtru_encrypt_file_params_c.h
* virtru_encrypt_string_params_c.h
* virtru_policy_c.h
* virtru_sample.c
* CMakeLists.txt


The following binaries / minified libraries are subject to use under the "Virtru Data Protection Subscription Agreement" 
found here: https://www.virtru.com/terms-of-service/ 

* libvirtru_tdf3_static.a
* libvirtru_tdf3_static_combined.a
* libvirtru_tdf3.dylib
* libvirtru_tdf3.so
* virtru_tdf3_static.lib
* virtru_tdf3_static_combined.lib
* virtru_tdf3.dll
* tdf3
* tdf3.exe

All 3rd party packages used in this software are covered by their respective
licenses, which are detailed in the LICENSE file.

## Obtaining a Virtru AppId

 A Virtru `AppId` token is required to use the TDF3 SDK. [This is how you obtain it](https://developer.virtru.com/docs/how-to-download-appid-token) 

## The Virtru TDF3 C++ Sample

For more information on how to use the TDF3 C++ libraries, see the [online documentation](https://docs.developer.virtru.com/cpp/latest).

### Windows

1. Unpack the zip file

2. Open a command prompt window, and go to the `cpp-sample` directory 

3. Generate the Visual Studio files using cmake (https://cmake.org) by issuing the command `cmake -G "Visual Studio 15 2017 Win64"`

4. Open the `virtru_tdf3_sample.sln` file with Visual Studio

5. Select `Release` in the configuation mode dropdown

6. Edit the `virtru_sample.cpp` file and fill in your owner email address and associated appId values.

7. Select `Build solution` under the `Build` menu to do the compile and link

8. Run the resulting `virtru_tdf3_sample.exe` executable 

### OSX

1. Unpack the tar.gz file

2. Open a terminal window, and go to the `cpp-sample` directory 

3. Generate the makefile using cmake (https://cmake.org) by issuing the command `cmake .`

4. Edit the `virtru_sample.cpp` file and fill in your owner email address and associated appId values.

5. Issue the command `make` to do the compile and link

6. Run the resulting `virtru_tdf3_sample` executable 

### Linux

1. Unpack the tar.gz file

2. Open a terminal window, and go to the `cpp-sample` directory 

3. Generate the makefile using cmake (https://cmake.org) by issuing the command `cmake -G "Eclipse CDT4 - Unix Makefiles"`

4. Edit the `virtru_sample.cpp` file and fill in your owner email address and associated appId values.

5. Issue the command `make` to do the compile and link

6. Run the resulting `virtru_tdf3_sample` executable 